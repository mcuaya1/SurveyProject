#ifndef SURVEYCLASS_H
#define SURVEYCLASS_H
#include <string>
#include <iostream>
#include <vector>

using namespace std;

class surveyQuestion{
  public:
    surveyQuestion();
    surveyQuestion(vector<string>, vector<string>, vector<int>);

    void setSurveyQuestions();
    void setSurveyResponse();
    void setResponseSize();

    vector<string> getSurveyQuests();
    vector<string> getSurveyRespon();
    vector<int> getResponSize();

  private:
    vector<string> surveyQuestions;
    vector<string> surveyResponse;
    vector<int> responseSize;
};

class surveyClass{
  private:
    string topic;
    int surveyID;
    int numOfQuestions;
    surveyQuestion questions;
    

    vector<string> surveyQuestions;
    vector<string> surveyResponse;
    vector<int> responseSize;

  public:
    surveyClass(string topic, int numOfQuestions, surveyQuestion, int surveyID);

    string getToptic();
    int getSurveyID();
    int getNumOfQuests();
    surveyQuestion getSurveyQuest();

    vector<string> getSurveyQuests();
    vector<string> getSurveyRespon();
    vector<int> getResponSize();
    
};


#endif