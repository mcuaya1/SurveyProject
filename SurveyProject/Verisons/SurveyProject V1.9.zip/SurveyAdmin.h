#ifndef SURVEYADMIN_H
#define SURVEYADMIN_H
#include <string>
#include <iostream>
#include <vector>
#include "SurveyClass.h"
#include "SurveyUser.h"
using namespace std;

class surveyAdmin{
    public:
        surveyAdmin(string,string);
        void viewerUsers();
        void deleteUser();
        void editUserInfo();
        vector<surveyUser> passUserInfo();
        void setUserInfo(vector<surveyUser>);


        surveyClass createSurvey();
        void storeSurveyInfo(surveyClass);
        void viewCurrentSurveys();
        void deleteSurvey();
        void editSurvey();
        void viewSurveyQuests();
        void deleteSurveyQuests();

        string getAdminName();
        string getAdminPassword();
    private:
        string adminPassword;
        string adminName;
        vector<surveyUser> userInfoStored;
        vector<surveyClass> surveyStored;
    
};

#endif