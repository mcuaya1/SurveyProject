#include "SurveyClass.h"
#include <string>
#include <vector>
using namespace std;

surveyClass::surveyClass(string topic, int numOfQuestions, surveyQuestion questions, int surveyID){
    this->topic = topic;
    this->surveyID = surveyID;
    this->numOfQuestions = numOfQuestions;
    this->questions = questions;
};

string surveyClass::getToptic(){
  return topic;
};

int surveyClass::getSurveyID(){
  return surveyID;
};

int surveyClass::getNumOfQuests(){
  return numOfQuestions;
};

vector<string> surveyClass::getSurveyQuests(){
  return surveyQuestions;
};

vector<string> surveyClass::getSurveyRespon(){
  return surveyResponse;
};

vector<int> surveyClass::getResponSize(){
  return responseSize;
};

surveyQuestion surveyClass::getSurveyQuest(){
  return questions;
}


surveyQuestion::surveyQuestion(){
  cout << "Empty" << endl;
};

surveyQuestion::surveyQuestion(vector<string> surveyQuestions, vector<string> surveyRepsonse, vector<int> reponseSize ){
  this->surveyQuestions = surveyQuestions;
  this->surveyResponse = surveyRepsonse;
  this->responseSize = reponseSize;
};

vector<string> surveyQuestion::getSurveyQuests(){
  return surveyQuestions;
};
vector<string> surveyQuestion::getSurveyRespon(){
  return surveyResponse;
};
vector<int> surveyQuestion::getResponSize(){

};
