/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   SurveyClass.h
 * Author: Owner
 *
 * Created on March 15, 2021, 6:06 PM
 */

#ifndef SURVEYCLASS_H
#define SURVEYCLASS_H
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

class SurveyClass{
    public:
        //void createSurvey(int);
        //SurveyClass deleteSurvey(SurveyClass survey);
        //SurveyClass addSurvey(SurveyClass survey);
       // SurveyClass editSurvey(SurveyClass survey);
        //string setQuestion(string question);
    protected:
        int numOfQuestions;
        
    
};

class surveyUser:public SurveyClass{
    private:
        string userPassword;
        string userName;
        
    public:
        //Functions
        surveyUser(string, string);
        void viewUserInfo();
        void editAccountDetails();
        
        //Mutators
        void setUserName(string);
        void setUserPassword(string);
        
        //Accessors
        string getUserName();
        string getUserPassword();
        
      
};

class surveyClass:public SurveyClass {
    public:
        string topic;
        vector<string> surveyQuestions;
        vector<string> surveyResponse;
        int surveyID;
        surveyClass(string topic,vector<string>surveyQuestions, vector<string>surveyResponse, int surveyID);
};

class surveyAdmin:public SurveyClass{
    public:
        surveyAdmin(string,string);
        void storeUserInfo(surveyUser);
        void viewerUsers();
        void deleteUser();
        void editUserInfo();
        surveyClass createSurvey();
        void storeSurveyInfo(surveyClass);
        
    private:
        string adminPassword;
        string adminName;
        vector<surveyUser> userInfoStored;
        vector<surveyClass> surveyStored;
        fstream myfile;
    
    protected:
        void viewUserSurveyResults();
        void viewSurveyResults();       
};




#endif /* SURVEYCLASS_H */

