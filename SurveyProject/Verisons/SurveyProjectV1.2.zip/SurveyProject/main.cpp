/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Owner
 *
 * Created on February 28, 2021, 3:17 PM
 */

#include <cstdlib>
#include <iostream>
#include <vector>

#include "SurveyClass.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    cout << "Test" << endl;
    surveyAdmin testAdmin("Thomas", "Password123");
    surveyUser testUser1("testName","testPassword");
    surveyUser testUser2("testNam1","testPassword1");
    vector<surveyUser> surveyTest;
    vector<surveyUser> surveyTestTwo;
    surveyTest.push_back(testUser1);
    surveyTest.push_back(testUser2);
    
    for(int i = 0; i < surveyTest.size(); i++){
        surveyTestTwo.push_back(surveyTest[i]);
    }
   
    testAdmin.storeUserInfo(testUser1);
    testAdmin.storeUserInfo(testUser2); 
    //testAdmin.deleteUser();
    //testAdmin.viewerUsers();
    //testAdmin.editUserInfo();
    
    testUser1.viewUserInfo();
    
    testAdmin.createSurvey();
    
    return 0;
}

