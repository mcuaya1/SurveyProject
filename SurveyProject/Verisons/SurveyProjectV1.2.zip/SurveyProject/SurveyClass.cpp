/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include "SurveyClass.h"
#include <string>
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;


//Admin Class
surveyAdmin::surveyAdmin(string adminName, string adminPassword){
    this->adminName = adminName;
    this->adminPassword = adminPassword;
};

//Admin function to store user information into a vector list
void surveyAdmin::storeUserInfo(surveyUser user){
    userInfoStored.push_back(user);
 //   if(myfile){
 //       myfile << userInfoStored.push_back(user);
 //       myfile.close();
//    }
//   else{
//        cout << "error" << endl;
//    }
//    for(int i = 0; i < userInfoStored.size(); i++){
//        userInfoStored.push_back(user);
//    }
    
};

//Admin function to display viewers in the vector list
void surveyAdmin::viewerUsers(){
    for(int i = 0; i <userInfoStored.size(); i++){
        cout << "User " << i+1 << " information" << endl;
        cout << "User Name: " << userInfoStored[i].getUserName() << endl;
        cout << "User Password: " << userInfoStored[i].getUserPassword() << endl;
    }
};

//Admin function to delete user
void surveyAdmin::deleteUser(){
    int index;
    cout << "Current Users" << endl;
    viewerUsers();
    cout <<"Please enter the index value of the user which you would like to delete" << endl;
    cin >> index;
    userInfoStored.erase(userInfoStored.begin()+index);
};

//Admin function to create survey
surveyClass surveyAdmin::createSurvey() {
    string topic;
    int numOfQuestions;
    vector<string> surveyQuestions;
    string question;
    string responeForQuest;
    int responseSize;
    vector<string> surveyResponse;
    int surveyID;
    cout << "Please enter Survey topic" << endl;
    getline(cin, topic);
    cout << "Pleas enter amount of questions for this survey" << endl;
    cin >> numOfQuestions;
    cin.ignore();

    for (int i = 0; i < numOfQuestions; i++) {
        cout << "Please type what question " << i +1 << " would ask..." << endl;
        getline(cin, question);
        cout << "How many responses for this question?" << endl;
        cin >> responseSize;
        cin.ignore();
        for (int j = 0; j < responseSize; j++) {
            cout << "Please type response " << j + 1 << " for question " << i + 1 << endl;
            getline(cin, responeForQuest);
            surveyResponse.push_back(responeForQuest);
        }
        cin.clear();
        surveyQuestions.push_back(question);
    }
    
    cout << "Please type a unique 6 digit ID for this Survey" << endl;
    cin >> surveyID;

    return surveyClass(topic, surveyQuestions, surveyResponse, surveyID);
};

//Admin function to store surveyInfo
void surveyAdmin::storeSurveyInfo(surveyClass survey){
    surveyStored.push_back(survey);
};

//Admin function edit user info
void surveyAdmin::editUserInfo(){
     int index;
     string userName, userPassword;
    cout <<"Current Users " << endl;
    viewerUsers();
    
    cout <<"Please enter the index value of the user which you would like to edit" << endl;
    cin >> index;
    
    cin.ignore();
    cout << "Accessing User Info..." << endl;
    cout << userInfoStored[index].getUserName() << endl;
    cout << userInfoStored[index].getUserPassword() << endl;
    cout << "Enter a new user name" << endl;
    getline(cin,userName);
    cout << "Enter a new password" << endl;
    getline(cin,userPassword);
    userInfoStored[index].setUserName(userName);
    userInfoStored[index].setUserPassword(userPassword);
    cout << "User " << index << "'s updated information..." << endl;
    cout << userInfoStored[index].getUserName() << endl;
    cout << userInfoStored[index].getUserPassword() << endl;
};

//survey Class
surveyClass::surveyClass(string topic, vector<string>surveyQuestions, vector<string>surveyResponse, int surveyID){
    this->topic = topic;
    this->surveyQuestions = surveyQuestions;
    this->surveyQuestions = surveyResponse;
    this->surveyID = surveyID;
};

//User Class
surveyUser::surveyUser(string userName,string userPassword){
    this->userName = userName;
    this->userPassword = userPassword;
};

//User function to display account details
void surveyUser::viewUserInfo(){
    cout << "User Name: " << userName << endl;
    cout << "User Password " << userPassword << endl;
};

//User Accessors
string surveyUser::getUserName(){
    return userName;
};

string surveyUser::getUserPassword(){
    return userPassword;
};

//User Mutators
void surveyUser::setUserName(string userName){
    this->userName = userName;
};
void surveyUser::setUserPassword(string userPassword){
    this->userPassword = userPassword;
};



