/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include "SurveyClass.h"
#include <string>
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;


//Admin Class
surveyAdmin::surveyAdmin(string adminName, string adminPassword){
    this->adminName = adminName;
    this->adminPassword = adminPassword;
};

//Admin function to store user information into a vector list
void surveyAdmin::storeUserInfo(surveyUser user){
   userInfoStored.push_back(user);
   ofstream userInfoOUT;

    userInfoOUT.open("userInfoFile.txt", ios::app | ios::binary);
       userInfoOUT.write((char*)&user, sizeof(user));
       userInfoOUT.close();
};

//Admin function to display viewers in the vector list
void surveyAdmin::viewerUsers(){
    ifstream userInfoIN;
    //ifstream tempFile;
    surveyUser testUser("test4545","test14545");
    surveyUser testUser3("t533est4545","test43314545");
    
    
    userInfoIN.open("userInfoFile.txt", ios::in | ios::binary);
    //userInfoIN.seekg(0);

    userInfoIN.read((char *) &testUser, sizeof (testUser));
    while (userInfoIN) {
        cout << "Username: " << testUser.getUserName() << endl;
        cout << "Password: " << testUser.getUserPassword() << endl;
        userInfoIN.read((char *) &testUser, sizeof (testUser));
        if(userInfoIN.eof() == true){
            break;
        }
    }
    userInfoIN.close(); 
    
    /*
         if (flagCheck == 1) {
            cout << "FLAG CHECK" << endl;
            tempFile.open("tempFile.txt", ios::in | ios::binary);
            tempFile.read((char *)&testUser3, sizeof(testUser3));  
            tempFile.seekg(0);
        while(tempFile) {
            cout << "CHECK" << endl;
            cout << "Username: " << testUser3.getUserName() << endl;
            cout << "Password: " << testUser3.getUserPassword() << endl;
            tempFile.read((char*)&testUser3, sizeof(testUser3));
            }
            tempFile.close(); 
        } 
        else{
            userInfoIN.open("userInfoFile.txt", ios::in | ios::binary);
            userInfoIN.seekg(0);
    
            userInfoIN.read((char *) &testUser, sizeof (testUser));
            while (userInfoIN.eof() == false) {
                cout << "Username: " << testUser.getUserName() << endl;
                cout << "Password: " << testUser.getUserPassword() << endl;
                userInfoIN.read((char *) &testUser, sizeof (testUser));
            }
            userInfoIN.close(); 
        }
 */



 
 /*  
 
  */
};

//Admin function to delete user
void surveyAdmin::deleteUser(){
    ifstream userInfoIN;
    ofstream newUserInfo;
    fstream testFile;
    string userName;
    vector<surveyUser> userInfoStoredTest;
    surveyUser testUser("test54545","test145");
    surveyUser testUser2("test54545","test145");
    surveyUser testUser3("teefa43st54545","testfad34145");
    cout <<"Please enter the user name of the user which you would like deleted" << endl;
    cin >> userName;
    

    userInfoIN.open("userInfoFile.txt", ios::in | ios::binary);
    //userInfoStoredTest.push_back(testUser)
    userInfoIN.seekg(0);
    newUserInfo.open("tempFile.txt", ios::app | ios::binary);
    //newUserInfo.seekg(0);
    userInfoIN.read((char*)&testUser, sizeof(testUser));
    while(userInfoIN){
        if(testUser.getUserName() == userName){
            cout << "FOUND USER AND DELETED..." << endl;
        }
        else{
            //newUserInfo.write((char *) &testUser, sizeof (testUser));
            //testUser2.setUserName(testUser.getUserName()); 
            //testUser2.setUserPassword(testUser.getUserPassword()); 
            userInfoStoredTest.push_back(testUser);
            cout << "WRITING TO FILE" << endl;
            cout << testUser.getUserName() << endl;
            cout << testUser.getUserPassword() << endl;
            //newUserInfo.write((char*)&testUser2, sizeof(testUser2));
        }
        userInfoIN.read((char *)&testUser, sizeof(testUser));
    }

        cout << "END OF WRITING TO FILE" << endl;
   //userInfoStoredTest.erase(userInfoStoredTest.begin() + (userInfoStoredTest.size()-1)); 
    for(int i = 0; i < userInfoStoredTest.size(); i++){
        if(userInfoStoredTest[i].getUserName() == userName){
            userInfoStoredTest.erase(userInfoStoredTest.begin() + i);
        }
        //newUserInfo.write((char *) &userInfoStoredTest[i], sizeof (userInfoStoredTest[i]));
    }
        cout << "Checking elements in the vector " << endl;     
   for(int i = 0; i < userInfoStoredTest.size(); i++){
       testUser2.setUserName(userInfoStoredTest[i].getUserName());
       testUser2.setUserPassword(userInfoStoredTest[i].getUserPassword());
       //cout << userInfoStoredTest[i].getUserName() << endl;
       //cout << userInfoStoredTest[i].getUserPassword() << endl;
       newUserInfo.write((char*)&testUser2, sizeof(testUser2));
   }

/*
    cout << "TEST" << endl;
    newUserInfo.seekg(0);
    newUserInfo.read((char *) &testUser2, sizeof(testUser2));
    while(newUserInfo){
        cout << "Username: " << testUser2.getUserName() << endl;
        cout << "Password: " << testUser2.getUserPassword() << endl; 
       newUserInfo.read((char *) &testUser2, sizeof(testUser2));
       if(newUserInfo.eof() == true){
           break;
       }
    }
 */   
    userInfoIN.close();
    newUserInfo.close();
    //flagCheck = 1;
    remove("userInfoFile.txt");
    rename("tempFile.txt","userInfoFile.txt");

    cout << "CHECKING THE FILE..." << endl;
    testFile.open("tempFile.txt", ios::in | ios::binary);
    testFile.read((char*) &testUser2, sizeof (testUser2));
    while(testFile){
        cout << testUser2.getUserName() << endl;
        cout << testUser2.getUserPassword() << endl;
        testFile.read((char *) &testUser2, sizeof (testUser2));
        if(testFile.eof() == true){
            break;
        }
    }
    testFile.close();
   
};

//Admin function to create survey
surveyClass surveyAdmin::createSurvey() {
    string topic;
    int numOfQuestions;
    vector<string> surveyQuestions;
    string question;
    string responeForQuest;
    int responseSize;
    vector<string> surveyResponse;
    vector<int> responseSizeList;
    int surveyID;
    
    cout << "Please enter Survey topic" << endl;
    getline(cin, topic);
    cout << "Please enter amount of questions for this survey" << endl;
    cin >> numOfQuestions;
    cin.ignore();

    for (int i = 0; i < numOfQuestions; i++) {
        cout << "Please type what question " << i +1 << " would ask..." << endl;
        getline(cin, question);
        surveyQuestions.push_back(question);
        cout << "How many responses for this question?" << endl;
        cin >> responseSize;
        responseSizeList.push_back(responseSize);
        cin.ignore();
        for (int j = 0; j < responseSize; j++) {
            cout << "Please type response " << j + 1 << " for question " << i + 1 << endl;
            getline(cin, responeForQuest);
            surveyResponse.push_back(responeForQuest);
        }
       
        cin.clear();
    }
    
    cout << "Please type a unique 6 digit ID for this Survey" << endl;
    cin >> surveyID;
    
    cin.ignore();
    return surveyClass(topic, numOfQuestions, responseSizeList, surveyQuestions, surveyResponse, surveyID);
};

//Admin function to view current Surveys
void surveyAdmin::viewCurrentSurveys(){
    int flagCheck;
    int surveyID;
    int counter = 0;
    for(int i = 0; i < surveyStored.size(); i++){
        cout << "Survey " << i + 1 << endl;
        cout << "----------------" << endl;
        cout << "Survey Topic: " << surveyStored[i].topic << endl;
        cout << "Amount of questions in this survey: " << surveyStored[i].numOfQuestions << endl;
        cout << "Survey ID: " << surveyStored[i].surveyID << endl;
    }
    cout << "If you would like to view a speific Survey's questions please type 1, else type 0" << endl;
    cin >> flagCheck;
    if(flagCheck = 1){
        cout << "Please type the Survey ID" << endl;
        cin >> surveyID;
        for(int i = 0; i < surveyStored.size(); i++){
            if(surveyID == surveyStored[i].surveyID){
                for(int j = 0; j < surveyStored[i].surveyQuestions.size(); j++){
                    cout << "Question " << j+1 <<  ": " << surveyStored[i].surveyQuestions[j] << endl;
                    for(int r = 0; r < surveyStored[i].responseSize[j]; r++){
                        cout << "Response " << r + 1  << ": " << surveyStored[i].surveyResponse[counter]<< endl;
                        counter++;
                    }
                }
                break;
            }
        }
    }
};

//Admin function to delete survey
void surveyAdmin::deleteSurvey(){
    int ID;
    cout << "Please type the id of the survey which you would like to delete " << endl;
    cin >> ID;
    for(int i = 0; i < surveyStored.size(); i++){
        if(surveyStored[i].surveyID == ID){
            surveyStored.erase(surveyStored.begin() + i);
            break;
        }
    }
}

//Admin function to store surveyInfo
void surveyAdmin::storeSurveyInfo(surveyClass survey){
    surveyStored.push_back(survey);
};

/*
//Admin function edit user info
void surveyAdmin::editUserInfo(){
     int index;
     string userName, userPassword;
    cout <<"Current Users " << endl;
    viewerUsers();
    
    cout <<"Please enter the index value of the user which you would like to edit" << endl;
    cin >> index;
    
    cin.ignore();
    cout << "Accessing User Info..." << endl;
    cout << userInfoStored[index].getUserName() << endl;
    cout << userInfoStored[index].getUserPassword() << endl;
    cout << "Enter a new user name" << endl;
    getline(cin,userName);
    cout << "Enter a new password" << endl;
    getline(cin,userPassword);
    userInfoStored[index].setUserName(userName);
    userInfoStored[index].setUserPassword(userPassword);
    cout << "User " << index << "'s updated information..." << endl;
    cout << userInfoStored[index].getUserName() << endl;
    cout << userInfoStored[index].getUserPassword() << endl;
};
*/
//survey Class
surveyClass::surveyClass(string topic, int numOfQuestions, vector<int>responseSize, vector<string>surveyQuestions, vector<string>surveyResponse, int surveyID){
    this->topic = topic;
    this->surveyQuestions = surveyQuestions;
    this->surveyResponse = surveyResponse;
    this->responseSize = responseSize;
    this->surveyID = surveyID;
    this->numOfQuestions = numOfQuestions;
};

//User Class
surveyUser::surveyUser(string userName,string userPassword){
    this->userName = userName;
    this->userPassword = userPassword;
};

//User function to display account details
void surveyUser::viewUserInfo(){
    cout << "User Name: " << userName << endl;
    cout << "User Password " << userPassword << endl;
};

//User Accessors
string surveyUser::getUserName(){
    return userName;
};

string surveyUser::getUserPassword(){
    return userPassword;
};

//User Mutators
void surveyUser::setUserName(string userName){
    this->userName = userName;
};
void surveyUser::setUserPassword(string userPassword){
    this->userPassword = userPassword;
};



