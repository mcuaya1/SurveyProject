#include "SurveyUser.h"
#include <string>
#include <iostream>
using namespace std;

//User Class
surveyUser::surveyUser(string username, string userpassword){
  this->userName = username;
  this->userPassword = userpassword;
}

//User function to display account details
void surveyUser::viewUserInfo(){
    cout << "User Name: " << userName << endl;
    cout << "User Password " << userPassword << endl;
};

//User Accessors
string surveyUser::getUserName(){
    return userName;
};

string surveyUser::getUserPassword(){
    return userPassword;
};

//User Mutators
void surveyUser::setUserName(string userName){
    this->userName = userName;
};

void surveyUser::setUserPassword(string userPassword){
    this->userPassword = userPassword;
};

