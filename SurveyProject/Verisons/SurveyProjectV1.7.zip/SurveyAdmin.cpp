#include "SurveyAdmin.h"
#include "SurveyClass.h"
#include <string>
#include <vector>
#include <iostream>
using namespace std;

surveyAdmin::surveyAdmin(string adminName, string adminPassword){
    this->adminName = adminName;
    this->adminPassword = adminPassword;
};

string surveyAdmin::getAdminName(){
  return adminName;
};

string surveyAdmin::getAdminPassword(){
  return adminPassword;
};

surveyClass surveyAdmin::createSurvey() {
    string topic;
    int numOfQuestions;
    vector<string> surveyQuestions;
    string question;
    string responeForQuest;
    int responseSize;
    vector<string> surveyResponse;
    vector<int> responseSizeList;
    int surveyID;
    
    cout << "Please enter Survey topic" << endl;
    getline(cin, topic);
    cout << "Please enter amount of questions for this survey" << endl;
    cin >> numOfQuestions;
    cin.ignore();

    for (int i = 0; i < numOfQuestions; i++) {
        cout << "Please type what question " << i +1 << " would ask..." << endl;
        getline(cin, question);
        surveyQuestions.push_back(question);
        cout << "How many responses for this question?" << endl;
        cin >> responseSize;
        responseSizeList.push_back(responseSize);
        cin.ignore();
        for (int j = 0; j < responseSize; j++) {
            cout << "Please type response " << j + 1 << " for question " << i + 1 << endl;
            getline(cin, responeForQuest);
            surveyResponse.push_back(responeForQuest);
        }
       
        cin.clear();
    }
    
    cout << "Please type a unique 6 digit ID for this Survey" << endl;
    cin >> surveyID;
    
    cin.ignore();
    return surveyClass(topic, numOfQuestions, responseSizeList, surveyQuestions, surveyResponse, surveyID);
};

//Admin function to view current Surveys
void surveyAdmin::viewCurrentSurveys(){
    int flagCheck;
    int surveyID;
    int counter = 0;
    vector <string> tempQuestions;
    vector <string> tempResponse;
    vector <int> tempResponseSize;


    for(int i = 0; i < surveyStored.size(); i++){
        cout << "Survey " << i + 1 << endl;
        cout << "----------------" << endl;
        cout << "Survey Topic: " << surveyStored[i].getToptic() << endl;
        cout << "Amount of questions in this survey: " << surveyStored[i].getNumOfQuests() << endl;
        cout << "Survey ID: " << surveyStored[i].getSurveyID() << endl;
    }
    cout << "Type the survey ID of the survey which you would like to to view further..." << endl;
    cin >> surveyID;

    for(int i = 0; i < surveyStored.size(); i++){
        if(surveyStored[i].getSurveyID() == surveyID){
          tempQuestions = surveyStored[i].getSurveyQuests();
          tempResponse = surveyStored[i].getSurveyRespon();
          tempResponseSize = surveyStored[i].getResponSize();
        }
      }
     
      for(int j = 0; j < tempQuestions.size(); j++){
          cout << "Question " << j+1 <<  ": " << tempQuestions[j] << endl;
            for(int r = 0; r < tempResponseSize[j]; r++){
              cout << "Response " << r + 1  << ": " << tempResponse[counter]<< endl;
                      counter++;
            }
      }
};


void surveyAdmin::editSurvey(){
    int flagCheck;
    int surveyID;
    int counter = 0;


    for(int i = 0; i < surveyStored.size(); i++){
        cout << "Survey " << i + 1 << endl;
        cout << "----------------" << endl;
        cout << "Survey Topic: " << surveyStored[i].getToptic() << endl;
        cout << "Amount of questions in this survey: " << surveyStored[i].getNumOfQuests() << endl;
        cout << "Survey ID: " << surveyStored[i].getSurveyID() << endl;
    }
    cout << "Type the survey ID of the survey which you would like to edit..." << endl;
    cin >> surveyID;
    cout << "What would you like to edit... " << endl;
    for(int i = 0; i < surveyStored.size(); i++){
        if(surveyStored[i].getSurveyID() == surveyID){
            surveyStored[i] = createSurvey();
        }
      }
};


void surveyAdmin::deleteSurvey(){
    int ID;
    cout << "Please type the id of the survey which you would like to delete..." << endl;
    cin >> ID;
    for(int i = 0; i < surveyStored.size(); i++){
        if(surveyStored[i].getSurveyID() == ID){
            surveyStored.erase(surveyStored.begin() + i);
            break;
        }
    }
}


void surveyAdmin::viewerUsers(){
  for(int i = 0; i < userInfoStored.size(); i++){
    cout << "Username: " << userInfoStored[i].getUserName() << endl;
    cout << "Password: " << userInfoStored[i].getUserPassword() << endl;
  }
};

void surveyAdmin::deleteUser(){
  string username;
  viewerUsers();

  cout << "Please enter the username of the user which you would like to delete..." << endl;
  cin >> username;
  for(int i = 0; i < userInfoStored.size(); i++){
    if(username == userInfoStored[i].getUserName()){
      userInfoStored.erase(userInfoStored.begin() + i);
      break;
    }
  }
}

void surveyAdmin::editUserInfo(){
  string username;
  string password;
  viewerUsers();

  cout << "Please enter the username of the user which you would like to edit..." << endl;
  cin >> username;
  for(int i = 0; i < userInfoStored.size(); i++){
    if(username == userInfoStored[i].getUserName()){
      cout << "Please enter the new username for this user..." << endl;
      cin >> username;
      userInfoStored[i].setUserName(username);
      cout << "Please enter the new password for this user..." << endl;
      cin >> password;
      userInfoStored[i].setUserPassword(password);
      break;
    }
  }
}

vector<surveyUser> surveyAdmin::passUserInfo(){
  return userInfoStored;
}

void surveyAdmin::storeSurveyInfo(surveyClass survey){
  surveyStored.push_back(survey);
};

void surveyAdmin::setUserInfo(vector<surveyUser> userInfo){
  this->userInfoStored = userInfo;
}