#ifndef SURVEYENGINE_H
#define SURVEYENGINE_H
#include "SurveyAdmin.h"
#include "SurveyUser.h"
#include <string>
#include <vector>

using namespace std;

class SurveyEngine{
  public:
    SurveyEngine();
    void createAccount();
    void menu();
    void adminMenu(surveyAdmin);
    bool checkUser(surveyUser);
    bool checkAdmin(surveyAdmin);
    
    void storeUserInfo(surveyUser);
    void storeAdminInfo(surveyAdmin);

    surveyUser currUser(surveyUser);
    surveyAdmin currAdmin(surveyAdmin);

    vector <surveyUser> passUsers();

    void setUserInfo(vector <surveyUser>);
  private:
    vector <surveyUser> userINFO;
    vector <surveyAdmin> adminINFO;
    
};

#endif