#ifndef SURVEYUSER_H
#define SURVEYUSER_H
#include <string>
#include <iostream>


using namespace std;
class surveyUser{
    public:
        //Functions
      surveyUser(string, string);
      void viewUserInfo();
      void editAccountDetails();
        
        //Mutators
      void setUserName(string);
      void setUserPassword(string);
        
        //Accessors
      string getUserName();
      string getUserPassword();
           

    private:
        string userPassword;
        string userName;
        
};
#endif