#include "SurveyClass.h"
#include <string>
#include <vector>
using namespace std;

surveyClass::surveyClass(string topic, int numOfQuestions, vector<int>responseSize, vector<string>surveyQuestions, vector<string>surveyResponse, int surveyID){
    this->topic = topic;
    this->surveyQuestions = surveyQuestions;
    this->surveyResponse = surveyResponse;
    this->responseSize = responseSize;
    this->surveyID = surveyID;
    this->numOfQuestions = numOfQuestions;
};

string surveyClass::getToptic(){
  return topic;
};

int surveyClass::getSurveyID(){
  return surveyID;
};

int surveyClass::getNumOfQuests(){
  return numOfQuestions;
};

vector<string> surveyClass::getSurveyQuests(){
  return surveyQuestions;
}

vector<string> surveyClass::getSurveyRespon(){
  return surveyResponse;
}

vector<int> surveyClass::getResponSize(){
  return responseSize;
}