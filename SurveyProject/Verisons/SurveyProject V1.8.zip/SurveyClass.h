#ifndef SURVEYCLASS_H
#define SURVEYCLASS_H
#include <string>
#include <iostream>
#include <vector>

using namespace std;

class surveyClass{
  private:
    string topic;
    int surveyID;
    int numOfQuestions;

    vector<string> surveyQuestions;
    vector<string> surveyResponse;
    vector<int> responseSize;

  public:
    surveyClass(string topic, int numOfQuestions, vector<int> responseSize, vector<string>surveyQuestions,vector<string>surveyResponse, int surveyID);

    string getToptic();
    int getSurveyID();
    int getNumOfQuests();

    vector<string> getSurveyQuests();
    vector<string> getSurveyRespon();
    vector<int> getResponSize();
    
};

class surveyQuestions{
  private:
    vector<string> surveyQuestions;
    vector<string> surveyResponse;
    vector<int> responseSize;

  public:
    surveyQuestions(vector<string>, vector<string>, vector<int>);

}

#endif