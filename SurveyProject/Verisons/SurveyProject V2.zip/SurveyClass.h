#ifndef SURVEYCLASS_H
#define SURVEYCLASS_H
#include <string>
#include <iostream>
#include <vector>

using namespace std;

class surveyQuestion{
  public:
    surveyQuestion();
    surveyQuestion(string question);

    void setSurveyResponse();
    void setSurveyQuest();

    vector<string> getSurveyRespon();
    string getQuestion();

  private:
    string question;
    vector<string> surveyResponse;
};

class surveyClass{
  private:
    string topic;
    int surveyID;
    int numOfQuestions;
    

    vector<surveyQuestion> surveyQuestions;
    vector<string> surveyResponse;
    vector<int> responseSize;

  public:
    surveyClass(string topic, int numOfQuestions, vector<surveyQuestion> surveyQuestions, int surveyID);

    string getToptic();
    int getSurveyID();
    int getNumOfQuests();
    vector<surveyQuestion> getSurveyQuest();
    
    void setSurveyQuest(vector<surveyQuestion> questions);
    void setNumOfQuests(int numOfQuestions);
};


#endif