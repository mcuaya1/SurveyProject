/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include "SurveyClass.h"
#include <string>
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;


//Admin Class
surveyAdmin::surveyAdmin(string adminName, string adminPassword){
    this->adminName = adminName;
    this->adminPassword = adminPassword;
};

//Admin function to store user information into a vector list
void surveyAdmin::storeUserInfo(surveyUser user){
    if(myfile){
        for(int i = 0; i < userInfoStored.size(); i++){
        myfile << userInfoStored.push_back(user);
        }
        myfile.close();
    }
    else{
        cout << "error" << endl;
    }
//    for(int i = 0; i < userInfoStored.size(); i++){
//        userInfoStored.push_back(user);
//    }
    
};

//Admin function to display viewers in the vector list
void surveyAdmin::viewerUsers(){
    for(int i = 0; i <userInfoStored.size(); i++){
        cout << "User " << i+1 << " information";
        userInfoStored[i].getUserName();
        userInfoStored[i].getUserPassword();
    }
};

//User Class
surveyUser::surveyUser(string userName,string userPassword){
    this->userName = userName;
    this->userPassword = userPassword;
};

//User Accessors
string surveyUser::getUserName(){
    return userName;
};

string surveyUser::getUserPassword(){
    return userPassword;
};

//User Mutators
void surveyUser::setUserName(string userName){
    this->userName = userName;
};
void surveyUser::setUserPassword(string userPassword){
    this->userPassword = userPassword;
};



