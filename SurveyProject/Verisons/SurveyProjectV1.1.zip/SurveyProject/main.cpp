/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Owner
 *
 * Created on February 28, 2021, 3:17 PM
 */

#include <cstdlib>
#include <iostream>
#include <vector>

#include "SurveyClass.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    cout << "Test" << endl;
    surveyUser testUser1("testName","testPassword");
    vector<surveyUser> surveyTest;
    vector<surveyUser> surveyTestTwo;
    surveyTest.push_back(testUser1);
    
    for(int i = 0; i < surveyTest.size(); i++){
        surveyTestTwo.push_back(surveyTest[i]);
    }
    
    vector<int> test;
    test.push_back(1);
    return 0;
}

