/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   SurveyClass.h
 * Author: Owner
 *
 * Created on March 15, 2021, 6:06 PM
 */

#ifndef SURVEYCLASS_H
#define SURVEYCLASS_H
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

class SurveyClass{
    public:
        //void createSurvey(int);
        //SurveyClass deleteSurvey(SurveyClass survey);
        //SurveyClass addSurvey(SurveyClass survey);
       // SurveyClass editSurvey(SurveyClass survey);
        //string setQuestion(string question);
    protected:
        int numOfQuestions;
        
    
};

class surveyUser:public SurveyClass{
    private:
        string userPassword;
        string userName;
        
    public:
        surveyUser(string, string);
        
        //Mutators
        void setUserName(string);
        void setUserPassword(string);
        
        //Accessors
        string getUserName();
        string getUserPassword();
        
      
};

class surveyAdmin:public SurveyClass{
    public:
        surveyAdmin(string,string);
    private:
        string adminPassword;
        string adminName;
        vector<surveyUser> userInfoStored;
        fstream myfile;
    
    protected:
        void viewerUsers();
        surveyUser deleteUser(surveyUser user);
        surveyUser addUser(surveyUser user);
        void viewUserSurveyResults();
        void storeUserInfo(surveyUser);
        void viewSurveyResults();       
};



#endif /* SURVEYCLASS_H */

