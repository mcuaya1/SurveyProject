/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   SurveyClass.h
 * Author: Owner
 *
 * Created on March 15, 2021, 6:06 PM
 */

#ifndef SURVEYCLASS_H
#define SURVEYCLASS_H
#include <string>
using namespace std;

class SurveyClass{
    protected:
        string question;
        int numOfQuestions;
        SurveyClass createSurvey(string question, int numOfQuestions);
        SurveyClass deleteSurvey(SurveyClass survey);
        SurveyClass addSurvey(SurveyClass survey);
        SurveyClass editSurvey(SurveyClass survey);
    
    
};

class survey:public SurveyClass{

};

class surveyUser:public SurveyClass{
    public:
        surveyUser(string, string);
        
    private:
        string userPassword;
        string userName;
      
};

class surveyAdmin:public SurveyClass{
    public:
        surveyAdmin(string,string);
        
    private:
        string adminPassword;
        string adminName;
    
    protected:
        void viewerUsers();
        surveyUser deleteUser(surveyUser user);
        surveyUser addUser(surveyUser user);
        void viewUserSurveyResults();
        
        void viewSurveyResults();
        
        
};



#endif /* SURVEYCLASS_H */

