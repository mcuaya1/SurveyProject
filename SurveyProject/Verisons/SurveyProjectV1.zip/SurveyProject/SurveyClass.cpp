/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include "SurveyClass.h"
#include <string>
#include <iostream>
using namespace std;

SurveyClass SurveyClass::createSurvey(string question,int size){
    this->question = question;
    this->numOfQuestions = size;
};
