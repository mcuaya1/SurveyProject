#include "SurveyUser.h"
#include <string>
#include <iostream>
using namespace std;

//User Class constrocutor 
surveyUser::surveyUser(string username, string userpassword){
  this->userName = username;
  this->userPassword = userpassword;
}

//User function to display account details
void surveyUser::viewUserInfo(){
    cout << "User Name: " << userName << endl;
    cout << "User Password " << userPassword << endl;
};

//User Accessors
//Return username
string surveyUser::getUserName(){
    return userName;
};
//Return user password
string surveyUser::getUserPassword(){
    return userPassword;
};

//User Mutators
//Set username 
void surveyUser::setUserName(string userName){
    this->userName = userName;
};
//Set user password 
void surveyUser::setUserPassword(string userPassword){
    this->userPassword = userPassword;
};

