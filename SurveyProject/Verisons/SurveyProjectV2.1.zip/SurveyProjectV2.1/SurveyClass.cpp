#include "SurveyClass.h"
#include <string>
#include <vector>
using namespace std;


//SurveyClass Constructor 
surveyClass::surveyClass(string topic, int numOfQuestions, vector<surveyQuestion> questions, int surveyID){
    this->topic = topic;
    this->surveyID = surveyID;
    this->numOfQuestions = numOfQuestions;
    this->surveyQuestions = questions;
};

//Return topic
string surveyClass::getToptic(){
  return topic;
};

//Return survey ID
int surveyClass::getSurveyID(){
  return surveyID;
};

//Return number of questions in survey
int surveyClass::getNumOfQuests(){
  return numOfQuestions;
};
//Return vector of Survey Questions
vector<surveyQuestion> surveyClass::getSurveyQuest(){
  return surveyQuestions;
};

//Set vector of Survey Questions 
void surveyClass::setSurveyQuest(vector<surveyQuestion> questions){
  this->surveyQuestions = questions;
}
//Set number of questions
void surveyClass::setNumOfQuests(int numOfQuestions){
  this->numOfQuestions = numOfQuestions;
};

//Survey Question class consturcotr 
surveyQuestion::surveyQuestion(string question){
  this->question = question;
  int responseSize;
  string responseForQuest;
  cout << "How many responses for this question?" << endl;
        cin >> responseSize;
        cin.ignore();
        for (int j = 0; j < responseSize; j++) {
            cout << "Please type response " << j + 1 << " for question: " << question  << endl;
            getline(cin, responseForQuest);
            this->surveyResponse.push_back(responseForQuest);
        }
        cin.clear();
};

//Set userResponse vector 
void surveyQuestion::setUserResponse(vector<int> userResponse){
  this->userResponse = userResponse;
};

//Defulat Survey QUestion constructor 
surveyQuestion::surveyQuestion(){
  cout << "Empty question or temp question" << endl;
}

//Get vector of Survey reponses 
vector<string> surveyQuestion::getSurveyRespon(){
  return surveyResponse;
};
//Get Survey main question 
string surveyQuestion::getQuestion(){
  return question;
};
//Get vector of user reponse 
vector<int> surveyQuestion::getUserResponse(){
  return userResponse;
};