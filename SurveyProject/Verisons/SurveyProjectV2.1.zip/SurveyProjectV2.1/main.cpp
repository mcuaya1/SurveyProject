/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Owner
 *
 * Created on February 28, 2021, 3:17 PM
 */

#include "SurveyUser.h"
#include "SurveyAdmin.h"
#include "SurveyClass.h"
#include "SurveyEngine.h"
#include <cstdlib>
#include <iostream>
#include <vector>

using namespace std;

/*
 * 
 */
int main() {
    //creating user and admin objects
    surveyUser user1("Bob12","Bob1234");
    surveyAdmin admin1("Tom12", "Tom1234");
    //creating survey engine
    SurveyEngine engine;
    //storing user and admin info
    engine.storeUserInfo(user1);
    engine.storeAdminInfo(admin1);
    //lanuching menu
    engine.menu();

    
    return 0;
}

