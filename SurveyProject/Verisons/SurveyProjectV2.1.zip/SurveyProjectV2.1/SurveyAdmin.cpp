#include "SurveyAdmin.h"
#include "SurveyClass.h"
#include <string>
#include <vector>
#include <iostream>
using namespace std;

//Inilzitie survey admin object
surveyAdmin::surveyAdmin(string adminName, string adminPassword){
    this->adminName = adminName;
    this->adminPassword = adminPassword;
};
//return admin name
string surveyAdmin::getAdminName(){
  return adminName;
};
//return admin password
string surveyAdmin::getAdminPassword(){
  return adminPassword;
};

//Function that creates a survey 
surveyClass surveyAdmin::createSurvey() {
    cin.ignore();
    string topic;
    int numOfQuestions;
    vector<surveyQuestion> questionList;
    string question;
    int surveyID;
    
    cout << "Please enter Survey topic" << endl;
    getline(cin, topic);
    cout << "Please enter amount of questions for this survey" << endl;
    cin >> numOfQuestions;
    cin.ignore();
    for (int i = 0; i < numOfQuestions; i++) {
        cout << "Please type what question " << i +1 << " would ask..." << endl;
        getline(cin, question);
        surveyQuestion questions(question);
        questionList.push_back(questions);
        cin.clear();
    }
    
    cout << "Please type a unique 6 digit ID for this Survey" << endl;
    cin >> surveyID;
    
    cin.ignore();
    return surveyClass(topic, numOfQuestions, questionList, surveyID);
};

//Admin function to view current Surveys
void surveyAdmin::viewCurrentSurveys(){
    for(int i = 0; i < surveyStored.size(); i++){
        cout << "Survey " << i + 1 << endl;
        cout << "----------------" << endl;
        cout << "Survey Topic: " << surveyStored[i].getToptic() << endl;
        cout << "Amount of questions in this survey: " << surveyStored[i].getNumOfQuests() << endl;
        cout << "Survey ID: " << surveyStored[i].getSurveyID() << endl;
    }
};
//Admin function to view questions in a survey
void surveyAdmin::viewSurveyQuests(){
    int surveyID;
    int counter = 0;
    vector <string> tempResponse;
    vector <surveyQuestion> tempQuestions;
    string questionSurvey;

    cout << "Type the survey ID of the survey which you would like to to view further..." << endl;
    cin >> surveyID;

    for(int i = 0; i < surveyStored.size(); i++){
      if(surveyStored[i].getSurveyID() == surveyID){
        tempQuestions = surveyStored[i].getSurveyQuest();
        for(int i = 0; i < tempQuestions.size(); i++){
          cout << "Question " << i +1 << ": " << tempQuestions[i].getQuestion() << endl;;
          tempResponse = tempQuestions[i].getSurveyRespon();
          for(int i = 0; i < tempResponse.size(); i++){
            cout <<  "Repsone " << i + 1  << ": "<< tempResponse[i] << endl;

          }
        } 
      }
    }
}
//Admin function to delete survey questions 
void surveyAdmin::deleteSurveyQuests(){
    int surveyID;
    int questionLine;
    int tempNumQuests;
    vector <surveyQuestion> tempQuestions;

    cout << "Pleae type the survey ID which you would like to delete questions for " << endl;
    cin >> surveyID;
    cout << "Please type the Question number which you would like deleted " << endl;
    cin >> questionLine;
    for(int i = 0; i < surveyStored.size(); i++){
      if(surveyStored[i].getSurveyID() == surveyID ){
        tempQuestions = surveyStored[i].getSurveyQuest();
        for(int j = 0; j < tempQuestions.size(); j ++){
          if((j + 1) == questionLine){
            tempQuestions.erase(tempQuestions.begin() + j);
          }
        }
        tempNumQuests = surveyStored[i].getNumOfQuests();
        surveyStored[i].setSurveyQuest(tempQuestions);
        surveyStored[i].setNumOfQuests(tempNumQuests - 1);
        break;
      }
    }
}
//Admin function to add questions to a survey
void surveyAdmin::addSurveyQuests(){
    int surveyID;
    vector <surveyQuestion> tempQuestions;
    string question;

    cout << "Pleae type the survey ID which you would like to add questions for..." << endl;
    cin >> surveyID;
    cin.ignore();
    for(int i = 0; i < surveyStored.size(); i++){
      if(surveyStored[i].getSurveyID() == surveyID ){
        tempQuestions = surveyStored[i].getSurveyQuest();
        cout << "Please type what this question would ask..." << endl;
        getline(cin,question);
        surveyQuestion newQuestion(question);
        tempQuestions.push_back(newQuestion);
        surveyStored[i].setSurveyQuest(tempQuestions);
        break;
      }
    }
}
//Admin function to edit a survey
void surveyAdmin::editSurvey(){
    int flagCheck;
    int surveyID;
    int counter = 0;


    for(int i = 0; i < surveyStored.size(); i++){
        cout << "Survey " << i + 1 << endl;
        cout << "----------------" << endl;
        cout << "Survey Topic: " << surveyStored[i].getToptic() << endl;
        cout << "Amount of questions in this survey: " << surveyStored[i].getNumOfQuests() << endl;
        cout << "Survey ID: " << surveyStored[i].getSurveyID() << endl;
    }
    cout << "Type the survey ID of the survey which you would like to edit..." << endl;
    cin >> surveyID;
    for(int i = 0; i < surveyStored.size(); i++){
        if(surveyStored[i].getSurveyID() == surveyID){
            surveyStored[i] = createSurvey();
        }
      }
};

//Admin function to delete a survey 
void surveyAdmin::deleteSurvey(){
    int ID;
    cout << "Please type the id of the survey which you would like to delete..." << endl;
    cin >> ID;
    for(int i = 0; i < surveyStored.size(); i++){
        if(surveyStored[i].getSurveyID() == ID){
            surveyStored.erase(surveyStored.begin() + i);
            break;
        }
    }
}

//Admin function to view users
void surveyAdmin::viewerUsers(){
  for(int i = 0; i < userInfoStored.size(); i++){
    cout << "Username: " << userInfoStored[i].getUserName() << endl;
    cout << "Password: " << userInfoStored[i].getUserPassword() << endl;
  }
};
//Admin function to delete users 
void surveyAdmin::deleteUser(){
  string username;
  viewerUsers();

  cout << "Please enter the username of the user which you would like to delete..." << endl;
  cin >> username;
  for(int i = 0; i < userInfoStored.size(); i++){
    if(username == userInfoStored[i].getUserName()){
      userInfoStored.erase(userInfoStored.begin() + i);
      break;
    }
  }
}
//Admin function to edit user information
void surveyAdmin::editUserInfo(){
  string username;
  string password;
  viewerUsers();

  cout << "Please enter the username of the user which you would like to edit..." << endl;
  cin >> username;
  for(int i = 0; i < userInfoStored.size(); i++){
    if(username == userInfoStored[i].getUserName()){
      cout << "Please enter the new username for this user..." << endl;
      cin >> username;
      userInfoStored[i].setUserName(username);
      cout << "Please enter the new password for this user..." << endl;
      cin >> password;
      userInfoStored[i].setUserPassword(password);
      break;
    }
  }
}
//Admin function to view user reponse to survey
void surveyAdmin::viewUserResponse(){
    int surveyID;
    int counter = 0;
    int responseTrack;
    vector <string> tempResponse;
    vector <surveyQuestion> tempQuestions;
    vector <int> userResponse;
    string questionSurvey;

    cout << "Type the survey ID of the survey which you would like to to view the results for..." << endl;
    cin >> surveyID;
    for(int i = 0; i < surveyStored.size(); i++){
      if(surveyStored[i].getSurveyID() == surveyID){
        tempQuestions = surveyStored[i].getSurveyQuest();
        for(int j = 0; j < tempQuestions.size(); j ++){
          cout << "Question " << j +1 << ": " << tempQuestions[i].getQuestion() << endl;
          userResponse = tempQuestions[j].getUserResponse();
          tempResponse = tempQuestions[j].getSurveyRespon();
          for(int k = 0; k < tempResponse.size(); k++ ){
            counter++;
            for(int r = 0; r < userResponse.size(); r++){
              if(counter == userResponse[r]){
                 responseTrack++; 
              }
            cout << "Response " << k + 1 << " was chosen " << responseTrack << " amount of times..." << endl;
            }
          }
        }
      }
    }
};

//Admin function to pass user information to other classes
vector<surveyUser> surveyAdmin::passUserInfo(){
  return userInfoStored;
}
//Admin function to pass survey infomration to other classes 
vector<surveyClass> surveyAdmin::passSurveyInfo(){
  return surveyStored;
}
//Admin function to store survey information 
void surveyAdmin::storeSurveyInfo(surveyClass survey){
  surveyStored.push_back(survey);
};
//Admin function to store user information 
void surveyAdmin::setUserInfo(vector<surveyUser> userInfo){
  this->userInfoStored = userInfo;
}
//Admin function to set survey information
void surveyAdmin::setSurveyInfo(vector<surveyClass> surveyInfo){
  this->surveyStored = surveyInfo;
};