#ifndef SURVEYCLASS_H
#define SURVEYCLASS_H
#include <string>
#include <iostream>
#include <vector>

using namespace std;

class surveyQuestion{
  public:
    surveyQuestion();
    surveyQuestion(string question);

    void setSurveyResponse();
    void setSurveyQuest();
    void setUserResponse(vector<int> userResponse);
    

    vector<string> getSurveyRespon();
    string getQuestion();
    vector<int> getUserResponse();

  private:
    string question;
    vector<string> surveyResponse;
    vector<int> userResponse;
    
};

class surveyClass{
  private:
    string topic;
    int surveyID;
    int numOfQuestions;
    vector<surveyQuestion> surveyQuestions;

  public:
    surveyClass(string topic, int numOfQuestions, vector<surveyQuestion> surveyQuestions, int surveyID);

    string getToptic();
    int getSurveyID();
    int getNumOfQuests();
    vector<surveyQuestion> getSurveyQuest();
    
    void setSurveyQuest(vector<surveyQuestion> questions);
    void setNumOfQuests(int numOfQuestions);
};


#endif