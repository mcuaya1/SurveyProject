#ifndef SURVEYENGINE_H
#define SURVEYENGINE_H
#include "SurveyAdmin.h"
#include "SurveyUser.h"
#include <string>
#include <vector>

using namespace std;

class SurveyEngine{
  public:
    SurveyEngine();
    void createAccount();
    void menu();
    void adminMenu(surveyAdmin);
    bool checkUser(surveyUser);
    bool checkAdmin(surveyAdmin);
    
    void storeUserInfo(surveyUser);
    void storeAdminInfo(surveyAdmin);

    surveyUser currUser(surveyUser);
    surveyAdmin currAdmin(surveyAdmin);

    void viewSurveys();
    void viewSurveyQuestions();

    vector <surveyUser> passUsers();
    vector <surveyClass> passSurvey();
    void setUserInfo(vector <surveyUser>);
    void setSurveyInfo(vector <surveyClass>);

  private:
    vector <surveyUser> userINFO;
    vector <surveyAdmin> adminINFO;
    vector <surveyClass> surveyINFO;
    
};

#endif