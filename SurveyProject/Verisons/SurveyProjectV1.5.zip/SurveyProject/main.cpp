/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Owner
 *
 * Created on February 28, 2021, 3:17 PM
 */

#include <cstdlib>
#include <iostream>
#include <vector>

#include "SurveyClass.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    cout << "Test" << endl;
    surveyAdmin testAdmin("Thomas", "Password123");
    surveyUser testUser1("testName","testPassword");
    surveyUser testUser4("tes3aftName","testP532assword");
    surveyUser testUser2("testNam1","testPassword1");
    surveyUser testUser3("Tawdawd34","Password12adw3");
    surveyUser testUser5("ThomasHobbsfesfs2343","Pssefassword123");
    vector<surveyUser> surveyTest;
    vector<surveyUser> surveyTestTwo;
    surveyTest.push_back(testUser1);
    surveyTest.push_back(testUser2);
    
    for(int i = 0; i < surveyTest.size(); i++){
        surveyTestTwo.push_back(surveyTest[i]);
    }
    
    testAdmin.storeUserInfo(testUser2);
    testAdmin.storeUserInfo(testUser1);
    testAdmin.storeUserInfo(testUser3);
    testAdmin.deleteUser();
    //testAdmin.viewerUsers();
    //testAdmin.editUserInfo();
    cout <<"RAN" << endl;
    testAdmin.viewerUsers();
    //testAdmin.storeUserInfo(testUser5);
    //testAdmin.storeUserInfo(testUser4);
    testAdmin.deleteUser();
    cout <<"WORK???" << endl;
    //testAdmin.storeSurveyInfo(testAdmin.createSurvey());
    //testAdmin.storeSurveyInfo(testAdmin.createSurvey());
    //testAdmin.deleteSurvey();
    //testAdmin.viewCurrentSurveys();
    
    return 0;
}

