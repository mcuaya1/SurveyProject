#include "SurveyClass.h"
#include <string>
#include <vector>
using namespace std;

surveyClass::surveyClass(string topic, int numOfQuestions, vector<surveyQuestion> questions, int surveyID){
    this->topic = topic;
    this->surveyID = surveyID;
    this->numOfQuestions = numOfQuestions;
    this->surveyQuestions = questions;
};


string surveyClass::getToptic(){
  return topic;
};

int surveyClass::getSurveyID(){
  return surveyID;
};

int surveyClass::getNumOfQuests(){
  return numOfQuestions;
};
vector<surveyQuestion> surveyClass::getSurveyQuest(){
  return surveyQuestions;
};

void surveyClass::setSurveyQuest(vector<surveyQuestion> questions){
  this->surveyQuestions = questions;
}

void surveyClass::setNumOfQuests(int numOfQuestions){
  this->numOfQuestions = numOfQuestions;
};


surveyQuestion::surveyQuestion(string question){
  this->question = question;
  int responseSize;
  string responseForQuest;
  cout << "How many responses for this question?" << endl;
        cin >> responseSize;
        cin.ignore();
        for (int j = 0; j < responseSize; j++) {
            cout << "Please type response " << j + 1 << " for question: " << question  << endl;
            getline(cin, responseForQuest);
            this->surveyResponse.push_back(responseForQuest);
        }
        cin.clear();
};


void surveyQuestion::setUserResponse(vector<int> userResponse){
  this->userResponse = userResponse;
};

surveyQuestion::surveyQuestion(){
  cout << "Empty question or temp question" << endl;
}

vector<string> surveyQuestion::getSurveyRespon(){
  return surveyResponse;
};

string surveyQuestion::getQuestion(){
  return question;
};

vector<int> surveyQuestion::getUserResponse(){
  return userResponse;
};