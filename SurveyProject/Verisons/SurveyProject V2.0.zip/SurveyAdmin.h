#ifndef SURVEYADMIN_H
#define SURVEYADMIN_H
#include <string>
#include <iostream>
#include <vector>
#include "SurveyClass.h"
#include "SurveyUser.h"
using namespace std;

class surveyAdmin{
    public:
        surveyAdmin(string,string);
        void viewerUsers();
        void deleteUser();
        void editUserInfo();
        vector<surveyUser> passUserInfo();
        vector<surveyClass> passSurveyInfo();
        void setUserInfo(vector<surveyUser>);
        void setSurveyInfo(vector<surveyClass>);


        surveyClass createSurvey();
        void storeSurveyInfo(surveyClass);
        void viewCurrentSurveys();
        void deleteSurvey();
        void editSurvey();
        void viewSurveyQuests();
        void deleteSurveyQuests();
        void addSurveyQuests();
        void viewUserResponse();

        string getAdminName();
        string getAdminPassword();
    private:
        string adminPassword;
        string adminName;
        vector<surveyUser> userInfoStored;
        vector<surveyClass> surveyStored;
    
};

#endif