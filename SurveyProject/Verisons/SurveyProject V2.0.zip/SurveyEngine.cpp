#include "SurveyEngine.h"
#include "SurveyAdmin.h"
#include "SurveyClass.h"
#include "SurveyUser.h"
#include <string>
#include <vector>
#include <iostream>

SurveyEngine::SurveyEngine(){
  cout << "Welcome..." << endl;
}

void SurveyEngine::adminMenu(surveyAdmin admin){
  int flagCheck;
  int flagCheck1;
  int flagCheck2;
  int flagCheck3;
  int flagCheck4;
  userINFO = admin.passUserInfo();
  cout << "Welcome " << admin.getAdminName() << endl;
  do{
      cout << "1)View current users... " << endl;
      cout << "2)View Surveys..." << endl;
      cout << "3)View User Survey Results " << endl;
      cout << "4)View Questions of a survey..." << endl;
      cout << "5)Sign out..." << endl;
      cin >> flagCheck;
        if(flagCheck == 1){
          do{
            admin.setUserInfo(userINFO);
            admin.viewerUsers();
            cout <<"1)Delete a user..." << endl;
            cout <<"2)Edit a user..." << endl;
            cout <<"3)Return..." << endl;
            cin >> flagCheck1;
            if(flagCheck1 == 1){
              admin.deleteUser();
            }
            else if(flagCheck1 == 2){
              admin.editUserInfo();
            }
          }while(flagCheck1 !=3);
        }
        else if(flagCheck == 2){
          do{
            admin.viewCurrentSurveys();
            cout <<"1)Delete a survey..." << endl;
            cout <<"2)Create a new survey..." << endl;
            cout <<"3)Edit a survey..." << endl;
            cout <<"4)Return..." << endl;
            cin >> flagCheck2;
            if(flagCheck2 == 1){
              admin.deleteSurvey();
            }
            else if(flagCheck2 == 2){
              admin.storeSurveyInfo(admin.createSurvey());

            }
            else if(flagCheck2 == 3){
              admin.editSurvey();
            }
          }while(flagCheck2 !=4);  
        }
        else if(flagCheck == 3){
        do{
          admin.viewCurrentSurveys();
          admin.viewSurveyQuests();
          admin.viewUserResponse();
          cout << "1) Return..." << endl;
          cin >> flagCheck3;
          }while(flagCheck3 != 1);
        }
        else if(flagCheck == 4){
          do{
            admin.viewCurrentSurveys();
            admin.viewSurveyQuests();
            cout << "1)Delete Questions for a survey..." << endl;
            cout << "2)Add Questions to a survey..." << endl;
            cout << "3)Return..." << endl;
            cin >> flagCheck4;
            if(flagCheck4 == 1){
              admin.deleteSurveyQuests();
            }
            else if(flagCheck4 == 2){
              admin.addSurveyQuests();
            }
          }while(flagCheck4 != 3);
        }
  }while(flagCheck != 5);
  this->surveyINFO = admin.passSurveyInfo();
};

void SurveyEngine::menu(){
  int flagCheck;
  int flagCheck1;
  int surveyID;
  int surveyNum;
  string username;
  string password;
  char exitProgram;
  vector<surveyQuestion> tempQuestions;
  vector<string> tempResponse;
  do{
    cout << "Would you like to sign in or exit the program..." << endl;
    cout << "Type 'Y' to sign in or 'X' to exit the program..." << endl;
    cin >> exitProgram;
    if(exitProgram == 'Y'){
      cout << "Username: ";
      cin >> username;
      cout << "Password: ";
      cin >> password;
      surveyUser tempUser(username,password);
      surveyAdmin tempAdmin(username,password);
      if(checkUser(tempUser) == true){
        tempUser = currUser(tempUser);
        cout << "Welcome " << tempUser.getUserName() << endl;
        do{
        cout <<"1)View account details..." << endl;
        cout <<"2)View Surveys..." << endl;
        cout <<"3)Sign Out..." << endl;
        cin >> flagCheck;
        if(flagCheck == 1){
          tempUser.viewUserInfo();
        }
        else if(flagCheck == 2){
          viewSurveys();
          cout << "1)Take survey..." << endl;
          cout << "2)View survey questions..." << endl;
          cout << "3)Return..." << endl;
          cin >> flagCheck1;
          if(flagCheck1 == 1){
            cout << "Please type the survey ID which you would like to take..." << endl;
            cin >> surveyID;
            for(int i = 0; i < surveyINFO.size(); i++){
              if(surveyINFO[i].getSurveyID() == surveyID){
                tempQuestions = surveyINFO[i].getSurveyQuest();
                for(int j = 0; j < tempQuestions.size(); j++){
                  cout << "Question " << j + 1 << ": " << tempQuestions[j].getQuestion() << endl;
                  tempResponse = tempQuestions[j].getSurveyRespon();
                  for(int r = 0; r < tempResponse.size(); r++){
                    cout << "Repsonse " << r + 1 << ": " << tempResponse[r] << endl; 
                  }
                  cout << "Please type in the response number which you would like to pick for this question..." << endl;
                  cin >> surveyNum;
                  vector<int> surveyResponse;
                  surveyResponse.push_back(surveyNum);
                  tempQuestions[j].setUserResponse(surveyResponse);
                }
                surveyINFO[i].setSurveyQuest(tempQuestions);
              }
            }
          }
          else if(flagCheck1 == 2){
            viewSurveyQuestions();
          }
        }
        }while (flagCheck != 3);
      }
      else if(checkAdmin(tempAdmin) == true){
        tempAdmin = currAdmin(tempAdmin);
        tempAdmin.setUserInfo(userINFO);
        tempAdmin.setSurveyInfo(surveyINFO);
        adminMenu(tempAdmin);
      }
      else{
        cout << "No account was found. Would you like to create a new account?" << endl;
        cout << "Type 'Y' to create a new account else type 'X' to exit the program or type 'T' to try again..." << endl;
        cin >> exitProgram;
        if( exitProgram == 'Y'){
          createAccount();
        }
      }
    }
  }while(exitProgram != 'X' );
}

bool SurveyEngine::checkUser(surveyUser user){
  bool flagCheck = false;
  for(int i = 0; i < userINFO.size(); i++){
    if(user.getUserName() == userINFO[i].getUserName() && user.getUserPassword() == userINFO[i].getUserPassword()){
      flagCheck = true;
    }
  }
  return flagCheck;
}


bool SurveyEngine::checkAdmin(surveyAdmin admin){
  bool flagCheck = false;
  for(int i = 0; i < adminINFO.size(); i++){
    if(admin.getAdminName() == adminINFO[i].getAdminName() && admin.getAdminPassword() == adminINFO[i].getAdminPassword()){
      flagCheck = true;
    }
  }
  return flagCheck;
}

void SurveyEngine::createAccount(){
  string userName;
  string userPassword;
  cout << "Enter a username: " << endl;
  cin >> userName;
  cout << "Enter a password: " << endl;
  cin >> userPassword;
  surveyUser newUser(userName,userPassword);
  storeUserInfo(newUser);
};

surveyAdmin SurveyEngine::currAdmin(surveyAdmin admin){
  surveyAdmin tempAdmin("TEMP", "TEMP");
  for(int i = 0; i < adminINFO.size(); i++){
    if(admin.getAdminName() == adminINFO[i].getAdminName() && admin.getAdminPassword() == adminINFO[i].getAdminPassword()){
      tempAdmin = admin;
    }
  }
  return tempAdmin;
}
surveyUser SurveyEngine::currUser(surveyUser user){
  surveyUser tempUser("TEMP", "TEMP");
  for(int i = 0; i < userINFO.size(); i++){
    if(user.getUserName() == userINFO[i].getUserName() && user.getUserPassword() == userINFO[i].getUserPassword()){
      tempUser = user;
    }
  }
  return tempUser;
}


void SurveyEngine::viewSurveys(){
      for(int i = 0; i < surveyINFO.size(); i++){
        cout << "Survey " << i + 1 << endl;
        cout << "----------------" << endl;
        cout << "Survey Topic: " << surveyINFO[i].getToptic() << endl;
        cout << "Amount of questions in this survey: " << surveyINFO[i].getNumOfQuests() << endl;
        cout << "Survey ID: " << surveyINFO[i].getSurveyID() << endl;
    }
};

void SurveyEngine::viewSurveyQuestions(){
    int surveyID;
    int counter = 0;
    vector <string> tempResponse;
    vector <surveyQuestion> tempQuestions;
    string questionSurvey;

    cout << "Type the survey ID of the survey which you would like to to view further..." << endl;
    cin >> surveyID;

    for(int i = 0; i < surveyINFO.size(); i++){
      if(surveyINFO[i].getSurveyID() == surveyID){
        tempQuestions = surveyINFO[i].getSurveyQuest();
        for(int i = 0; i < tempQuestions.size(); i++){
          cout << "Question " << i +1 << ": " << tempQuestions[i].getQuestion() << endl;;
          tempResponse = tempQuestions[i].getSurveyRespon();
          for(int i = 0; i < tempResponse.size(); i++){
            cout <<  "Repsone " << i + 1  << ": "<< tempResponse[i] << endl;
          }
        } 
      }
    }
}

void SurveyEngine::storeAdminInfo(surveyAdmin admin){
  adminINFO.push_back(admin);
}

void SurveyEngine::storeUserInfo(surveyUser user){
  userINFO.push_back(user);
}

vector<surveyClass> SurveyEngine::passSurvey(){
  return surveyINFO;
};